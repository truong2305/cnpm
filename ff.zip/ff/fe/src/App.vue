<template>
  <div id="app">
    <transition name="fade">
      <show-popup v-if="showPopup"/>
    </transition>
    <loader />
    <the-header />
    <banner />
    <router-view />
    <call v-if="typeof(infomations) == 'object'" :phone="'0'+infomations.phone" :mess="infomations.link_mess"/>
    <slide-slider />
    <the-footer
      v-if="typeof(infomations) == 'object'"
      :phone="'0'+infomations.phone"
      :addr="infomations.address"
      :email="infomations.email"
      :ig="infomations.link_ig"
      :fb="infomations.link_fb"
      :name="infomations.name"
    />
  </div>
</template>
<script>
import Banner from "./components/Banner.vue";
import Call from "./components/Call.vue";
import Loader from "./components/Loader.vue";
import ShowPopup from './components/ShowPopup.vue';
import SlideSlider from "./components/SlideSlider.vue";
import TheFooter from "./components/TheFooter.vue";
import TheHeader from "./components/TheHeader.vue";
export default {
  components: { Loader, TheHeader, Banner, TheFooter, Call, SlideSlider, ShowPopup, },
  computed: {
    infomations() {
      return this.$store.state.infomations;
    },
     showPopup() {
      return this.$store.state.showPopup
    },
  },

  async created() {
    await this.$store.dispatch("getProducts");
    await this.$store.dispatch("getInfomations");
  },
};
</script>
<style lang="scss" scoped>
img {
  width: 100%;
}
#app {
.fade-enter-active {
  transition: 0.3s;
  opacity: 1;
}
.fade-enter {
  opacity: 0;
}
.fade-leave-to {
  opacity: 0;
}
.fade-leave-active {
  transition: opacity 0.3s ease;
}
}

</style>
