<!-- @format -->

<template>
  <div class="home">
    <feature />
    <div class="product-section mt-120 mb-120">
      <title-page
        class="text-center mb-md-4 mt-5"
        firstTitle="Nổi"
        lastTitle="Bật"
      />
      <div class="container">
        <div class="row product-lists">
          <product
            v-for="product in products"
            :product="product"
            :key="product.id"
          />
        </div>
      </div>
    </div>
    <div class="container mt-120 mb-4" >
        <div class="row">
          <carousel
            :per-page="1"
            :speed="1000"
            :paginationEnabled="false"
            :autoplay="true"
            :loop="true"
          >
            <slide class="col-12">
              <div class="text-center">
                <div class="owl-item cloned">
                  <div class="single-testimonial-slider">
                    <div class="client-avater">
                      <img src="../assets/avt5-min.jpg" alt="" />
                    </div>
                    <div class="client-meta">
                      <h3>Huyền Trang<span>Khách hàng</span></h3>
                      <p class="testimonial-body">
                        " Sed ut perspiciatis unde omnis iste natus error veritatis et quasi architecto beatae vitae
                        dict eaque ipsa quae ab illo inventore Sed ut perspiciatis unde omnis iste natus error sit
                        voluptatem accusantium "
                      </p>
                      <div class="last-icon">
                        <i class="fas fa-quote-right"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </slide>
              <slide class="col-12">
              <div class="text-center">
                <div class="owl-item cloned">
                  <div class="single-testimonial-slider">
                    <div class="client-avater">
                      <img src="../assets/avt1-min.jpg" alt="" />
                    </div>
                    <div class="client-meta">
                      <h3>Anh Phan<span>Khách hàng</span></h3>
                      <p class="testimonial-body">
                        " Sed ut perspiciatis unde omnis iste natus error veritatis et quasi architecto beatae vitae
                        dict eaque ipsa quae ab illo inventore Sed ut perspiciatis unde omnis iste natus error sit
                        voluptatem accusantium "
                      </p>
                      <div class="last-icon">
                        <i class="fas fa-quote-right"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </slide>
              <slide class="col-12">
              <div class="text-center">
                <div class="owl-item cloned">
                  <div class="single-testimonial-slider">
                    <div class="client-avater">
                      <img src="../assets/avt2-min.jpg" alt="" />
                    </div>
                    <div class="client-meta">
                      <h3>Phan Ngọc Thạch<span>Khách hàng</span></h3>
                      <p class="testimonial-body">
                        " Sed ut perspiciatis unde omnis iste natus error veritatis et quasi architecto beatae vitae
                        dict eaque ipsa quae ab illo inventore Sed ut perspiciatis unde omnis iste natus error sit
                        voluptatem accusantium "
                      </p>
                      <div class="last-icon">
                        <i class="fas fa-quote-right"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </slide>
              <slide class="col-12">
              <div class="text-center">
                <div class="owl-item cloned">
                  <div class="single-testimonial-slider">
                    <div class="client-avater">
                      <img src="../assets/avt-min.png" alt="" />
                    </div>
                    <div class="client-meta">
                      <h3>Diệu Hiền<span>Khách hàng</span></h3>
                      <p class="testimonial-body">
                        " Sed ut perspiciatis unde omnis iste natus error veritatis et quasi architecto beatae vitae
                        dict eaque ipsa quae ab illo inventore Sed ut perspiciatis unde omnis iste natus error sit
                        voluptatem accusantium "
                      </p>
                      <div class="last-icon">
                        <i class="fas fa-quote-right"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </slide>
              <slide class="col-12">
              <div class="text-center">
                <div class="owl-item cloned">
                  <div class="single-testimonial-slider">
                    <div class="client-avater">
                      <img src="../assets/avt3-min.jpg" alt="" />
                    </div>
                    <div class="client-meta">
                      <h3>Bảo Trần<span>Khách hàng</span></h3>
                      <p class="testimonial-body">
                        " Sed ut perspiciatis unde omnis iste natus error veritatis et quasi architecto beatae vitae
                        dict eaque ipsa quae ab illo inventore Sed ut perspiciatis unde omnis iste natus error sit
                        voluptatem accusantium "
                      </p>
                      <div class="last-icon">
                        <i class="fas fa-quote-right"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </slide>
              <slide class="col-12">
              <div class="text-center">
                <div class="owl-item cloned">
                  <div class="single-testimonial-slider">
                    <div class="client-avater">
                      <img src="../assets/avt6-min.jpg" alt="" />
                    </div>
                    <div class="client-meta">
                      <h3>Đặng Tiến<span>Khách hàng</span></h3>
                      <p class="testimonial-body">
                        " Sed ut perspiciatis unde omnis iste natus error veritatis et quasi architecto beatae vitae
                        dict eaque ipsa quae ab illo inventore Sed ut perspiciatis unde omnis iste natus error sit
                        voluptatem accusantium "
                      </p>
                      <div class="last-icon">
                        <i class="fas fa-quote-right"></i>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </slide>
          </carousel>
        </div>
      </div>
  </div>
</template>

<script>
import Feature from "../components/Feature.vue";
import Product from "../components/Product.vue";
import TitlePage from "../components/TitlePage.vue";
// @ is an alias to /src

export default {
  name: "Home",
  components: {
    Feature,
    Product,
    TitlePage,
  },
  computed: {
    products() {
      return this.$store.state.hotProducts;
    },
  },
  mounted() {
    setTimeout(() => {
      this.$store.commit("hotProducts");
    }, 1000);
  },
};
</script>

<style lang="scss" scoped>
.mt-120 {
  margin-top: 120px;
}
.mb-120 {
  margin-bottom: 120px;
}
.client-meta h3 {
  font-size: 20px;
  font-weight: 700;
  span {
    display: block;
    font-size: 70%;
    margin-top: 10px;
    color: #051922;
    font-weight: 600;
    opacity: 0.5;
  }
}
.client-avater {
  border-radius: 50%;
  overflow: hidden;
  width: 90px;
  height: 90px;
  margin: 0 auto;
  margin-bottom: 1.5rem;
  img {
    width: 100%;
    height: 100%;
    object-fit: cover;
  }
}
p.testimonial-body {
  font-size: 17px;
  font-style: italic;
  width: 700px;
  margin: 0 auto;
  line-height: 1.8;
  color: #999999;
  margin-top: 20px;
  @media (max-width: 767.9px) {
    width: auto;
  }
}
.last-icon {
  margin-top: 20px;
  font-size: 25px;
  opacity: 0.3;
}
.mb-120 {
  margin-bottom: 120px;
}
.single-latest-news {
  box-shadow: 0 0 20px #dddddd;
  transition: 0.3s;
  border-radius: 10px;
  overflow: hidden;
  height: 100%;
  .latest-news-bg {
    position: relative;
    height: 300px;
    background: #051922;
    .show-popup {
      position: absolute;
      top: 10px;
      right: 10px;
      z-index: 2;
      color: white;
      cursor: pointer;
      width: 30px;
      height: 30px;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    img {
      width: auto;
      height: auto;
      max-width: 100%;
      max-height: 300px;
      object-fit: cover;
    }
  }
}
p.blog-meta span {
  margin-right: 15px;
  opacity: 0.6;
  color: #051922;
  font-size: 0.85em;
}
.news-text-box {
  padding: 25px;
  border-bottom-left-radius: 5px;
  border-bottom-right-radius: 5px;
}
.single-latest-news h3 {
  font-size: 20px;
  line-height: 1.25em;
  font-weight: 700;
}

@media (max-width: 767.9px) {
  .mt-120 {
    margin-top: 50px;
  }
  .mb-120 {
    margin-bottom: 50px;
  }
}
</style>
