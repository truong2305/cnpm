<template>
  <div>
    <title-page class="mt-5 mb-4 text-center" firstTitle="Quản" lastTitle="Lý"/>
    <div class="container">
      <div class="row">
        <div class="col-12">
           <nav class="mb-md-5 mb-4">
        <ul class="nav nav-tabs">
          <li class="nav-item" ><router-link to="/admin2211" exact active-class="active">Tất cả</router-link></li>
          <li class="nav-item" ><router-link to="/admin2211/them-san-pham" active-class="active">Thêm sản phẩm</router-link></li>
          <li class="nav-item" ><router-link to="/admin2211/them-cong-trinh" exact active-class="active">Công trình</router-link></li>
          <li class="nav-item" ><router-link to="/admin2211/quan-li-don-hang" active-class="active">Đơn hàng</router-link></li>
          <li class="nav-item" ><router-link to="/admin2211/thong-tin-trang" active-class="active">Thông tin</router-link></li>
          <li class="nav-item ms-5" @click="logout"><b-icon icon="power" scale="1.5" aria-hidden="true"></b-icon></li>
        </ul>
      </nav>
        </div>
      </div>
    </div>
    <router-view/>
  </div>
</template>

<script>
import TitlePage from '../components/TitlePage.vue'
export default {
  components: {  TitlePage },
  methods : {
    logout() {
      if (confirm('Đăng xuất ?')) {
        localStorage.removeItem('token')
        this.$router.push({path : '/login'})
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.nav-tabs {
  border-bottom: none;
  justify-content: center;
  position: relative;
  li a {
    margin-bottom: 0;
    margin: 0 2rem;
    color: #999999;
    font-weight: 700;
    text-decoration: none;
    transition: 0.3s;
    font-size: 1.2rem;
    &:hover {
      color: black;
    }
  }
  li:last-child {
    cursor: pointer;
  }
  .active {
    color: #051922;
  }
}
</style>