

export const mutations = {
    setLoader(state) {
        state.loader = true
        setTimeout(() => {
            state.loader = false
        },500)
    },
    getCategories(state, data) {
        state.categories = data
    },
     getInfomations(state, data) {
        state.infomations = data
    },
    getProducts(state, data) {
        state.products = data.reverse()
    },
    hotProducts(state) {
        let  products = [...state.products]
        state.hotProducts = products.filter( item => item.hot === 1)
    },
    getNumberProductCart(state) {
        state.getNumberProductCart = JSON.parse(localStorage.getItem("products_cart")).length;
    },
    getCateProducts(state, data) {
        state.cateProducts = [...state.products].filter(item => item.cate_id == data)
        state.cateTitle = state.categories.find(item => item.id === data).name
    },
    getCarts(state,data) {
        state.carts = data.reverse()
    },
    getConstructions(state,data) {
        state.constructions = data.reverse()
    },
    getImgs(state,data) {
        state.imgs = data
        state.showPopup = true
    },
    hiddenPopup(state) {
        state.imgs = []
        state.showPopup = false
    },
   
    getProductDetail(state, id) {
       let product = [...state.products].find(item => item.id == id)
        state.productDetail = product
    }
}