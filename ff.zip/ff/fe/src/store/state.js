export const state = {
    loader : false,
    categories : [],
    products : [],
    hotProducts : [],
    getNumberProductCart : 0,
    cateProducts : [],
    cateTitle : '',
    infomations : [],
    carts : [],
    editProduct : {},
    constructions : [], 
    imgs : [],
    showPopup : false,
    productDetail : {}
}