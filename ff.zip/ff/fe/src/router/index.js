/** @format */

import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../views/Home.vue";
import {Base_url} from "../main";
import axios from "axios";
import store from "../store";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "Home",
    component: Home,
  },
  {
    path: "/admin2211",
    component: () => import(/* webpackChunkName: "admin" */ "../views/Admin.vue"),
    meta: {requiresAuth: true},
    children: [
      {
        path: "/admin2211/them-san-pham",
        meta: {requiresAuth: true,
          title: "Admin"},

        component: () => import(/* webpackChunkName: "admin" */ "../components/admin/AddProduct.vue"),
       
      },
      {
        path: "/admin2211/them-cong-trinh",
        meta: {requiresAuth: true,
          title: "Admin"},

        component: () => import(/* webpackChunkName: "admin" */ "../components/admin/AddConstructions.vue"),
       
      },
      {
        path: "/admin2211",
        meta: {requiresAuth: true, title: "Admin"},

        component: () => import(/* webpackChunkName: "admin" */ "../components/admin/EditProducts.vue"),
      },
      {
        path: "/admin2211/thong-tin-trang",
        meta: {requiresAuth: true, title: "Admin"},

        component: () => import(/* webpackChunkName: "admin" */ "../components/admin/InfoPage.vue"),
      },
      {
        path: "/admin2211/quan-li-don-hang",
        meta: {requiresAuth: true, title: "Admin"},

        component: () => import(/* webpackChunkName: "admin" */ "../components/admin/CartAdmin.vue"),
      },
    ],
  },
  {
    path: "/danh-muc",
    component: () => import(/* webpackChunkName: "admin" */ "../views/Category.vue"),
    meta: {
      title: "Danh mục",
    },
    children: [
      {
        path: "/danh-muc/:category",
        component: () => import(/* webpackChunkName: "admin" */ "../components/CategoryProducts.vue"),
        meta: {
          title: "Danh mục",
        },
      },
    ],
  },
  {
    path: "/gioi-thieu",
    component: () => import(/* webpackChunkName: "about" */ "../views/About.vue"),
    meta: {
      title: "Giới thiệu",
    },
  },
  {
    path: "/login",
    component: () => import(/* webpackChunkName: "about" */ "../components/Login.vue"),
    name: "login",
    meta: {
      title: "Đăng nhập",
    },
  },
  {
    path: "/dat-hang",
    component: () => import(/* webpackChunkName: "about" */ "../views/Cart.vue"),
    meta: {
      title: "Đặt hàng",
    },
  },
  {
    path: "/san-pham",
    name: "Products",
    component: () => import(/* webpackChunkName: "about" */ "../views/Products.vue"),
    meta: {
      title: "Sản phẩm",
    },
  },
 
  {
    path: "/san-pham/id=:id/:slug",
    name: "ProductDetail",
    component: () => import(/* webpackChunkName: "about" */ "../components/ProductDetail.vue"),
    meta: {
      title: "Sản phẩm",
    },
  },
  {
    path: "/cong-trinh",
    name: "Construction",
    component: () => import(/* webpackChunkName: "about" */ "../views/Construction.vue"),
    meta: {
      title: "Công trình",
    },
  },
  {
    path: "/lien-he",
    name: "Contact",
    component: () => import(/* webpackChunkName: "about" */ "../views/Contact.vue"),
    meta: {
      title: "Liên hệ",
    },
  },
  {
    path: "/*",
    name: "Error",
    component: () => import(/* webpackChunkName: "about" */ "../views/ErrorPage.vue"),
    meta: {
      title: "Not found",
    },
  },
];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes,
});

router.beforeEach((to, from, next) => {
  store.commit("setLoader");
  Vue.nextTick(() => {
    document.title = to.meta.title || "V-home Đà Lạt";
  });
  window.scrollTo({
    top: 0,
    left: 0,
  });
  if (to.name === "login") {
    axios
      .get(`${Base_url}/api/checkLogin`, {
        headers: {
          Authorization: "Bearer " + localStorage.getItem("token"),
        },
      })
      .then(() => {
        next({path: "/admin2211"});
      });
  } else if (to.meta.requiresAuth) {
    if (!localStorage.getItem("token")) {
      next({path: "/login"});
    } else {
      axios
        .get(`${Base_url}/api/checkLogin`, {
          headers: {
            Authorization: "Bearer " + localStorage.getItem("token"),
          },
        })
        .then(() => {
          next();
        })
        .catch(() => {
          next({path: "/login"});
        });
    }
  }
  next();
});
export default router;
