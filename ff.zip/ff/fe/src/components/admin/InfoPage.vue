<template>
  <div class="mb-5 info-page" v-if="typeof infomations === 'object'">
    <div class="container">
      <div class="row">
        <div class="col-8 offset-2 justify-content-between">
          <form action="" @submit.prevent="update">
            <div class="d-flex mb-3">
              <div style="flex: 1">
                <label for="">Tên</label>
                <input type="text" v-model="infomations.name" />
              </div>
            </div>
            <div class="d-flex mb-3">
              <div style="flex: 1">
                <label for="">Sđt 1</label>
                <input type="number" v-model="infomations.phone" />
              </div>
              <div style="flex: 1" class="ms-3">
                <label for="">Sđt 2</label>
                <input type="number" v-model="infomations.phone2" />
              </div>
            </div>
            <div class="d-flex mb-3">
              <div style="flex: 1">
                <label for="">Email</label>
                <input type="email" v-model="infomations.email" required />
              </div>
              <div style="flex: 1" class="ms-3">
                <label for="">Link ig</label>
                <input type="url" v-model="infomations.link_ig" required/>
              </div>
            </div>
            <div class="d-flex mb-3">
              <div style="flex: 1">
                <label for="">Địa chỉ</label>
                <input type="text" v-model="infomations.address" />
              </div>
              <div style="flex: 1" class="ms-3">
                <label for="">Zalo</label>
                <input type="number" v-model="infomations.zalo" />
              </div>
            </div>
            <div class="d-flex mb-3">
              <div style="flex: 1">
                <label for="">Link fb</label>
                <input type="url" v-model="infomations.link_fb" required/>
              </div>
              <div style="flex: 1" class="ms-3">
                <label for="">Tên fb</label>
                <input type="text" v-model="infomations.fb" />
              </div>
            </div>
            <div class="d-flex mb-3">
              <div style="flex: 1">
                <label for="">Link messenger</label>
                <input type="url" v-model="infomations.link_mess" required/>
              </div>
              <div style="flex: 1" class="ms-3">
                <label for="">Sđt Cường</label>
                <input type="number" v-model="infomations.phone_c" />
              </div>
            </div>
            <div class="d-flex mb-3">
              <div style="flex: 1">
                <label for="">Sđt Nam</label>
                <input type="number" v-model="infomations.phone_n" />
              </div>
              <div style="flex: 1" class="ms-3">
                <label for="">Sđt Hằng</label>
                <input type="number" v-model="infomations.phone_h" />
              </div>
            </div>
            <div class="d-flex mb-3">
              <div style="flex: 1">
                <label for="">Link ig Cường</label>
                <input type="url" v-model="infomations.ig_c" required/>
              </div>
              <div style="flex: 1" class="ms-3">
                <label for="">Link ig Nam</label>
                <input type="url" v-model="infomations.ig_n" required/>
              </div>
            </div>
            <div class="d-flex mb-3">
              <div style="flex: 1">
                <label for="">Link ig Hằng</label>
                <input type="url" v-model="infomations.ig_h" required/>
              </div>
              <div style="flex: 1" class="ms-3">
                <label for="">Link fb Cường</label>
                <input type="url" v-model="infomations.fb_c" required/>
              </div>
            </div>
            <div class="d-flex mb-3">
              <div style="flex: 1">
                <label for="">Link fb Nam</label>
                <input type="url" v-model="infomations.fb_n" required/>
              </div>
              <div style="flex: 1" class="ms-3">
                <label for="">Link fb Hằng</label>
                <input type="url" v-model="infomations.fb_h" required/>
              </div>
            </div>
            <div style="color : blue">
              {{ ss }}
            </div>
            <div class="text-end">
              <button :class="{ active: change }">Cập nhật</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      change: false,
      ss: "",
    };
  },
  computed: {
    infomations() {
      return this.$store.state.infomations;
    },
  },
  watch: {
    infomations: {
      handler(newI, old) {
        if (typeof old === "object") {
          this.change = true;
        }
      },
      deep: true,
    },
  },
  methods: {
    update() {
      if (this.change) {
        this.$store.dispatch("updateInfo", this.infomations);
        setTimeout(() => {
          this.ss = "Cập nhật thành công";
        }, 1000);
        setTimeout(() => {
          this.ss = "";
        }, 4000);
      } else return;
    },
  },
};
</script>

<style lang="scss" scoped>
.info-page {
  input {
    width: 100%;
    padding: 15px;
    border: 1px solid #ddd;
    border-radius: 3px;
  }
  button {
    font-weight: 700;
    text-transform: uppercase;
    font-size: 15px;
    border: none !important;
    padding: 15px 25px;
    transition: 0.3s;
    border-radius: 30px;
    cursor: inherit;
  }
  .active {
    cursor: pointer;
    background-color: #f28123;
    color: #051922;
    &:hover {
      background-color: #051922;
      color: #f28123;
    }
  }
}
</style>