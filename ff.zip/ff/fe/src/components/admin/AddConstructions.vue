<!-- @format -->

<template>
  <div>
    <div class="container mb-5">
      <div class="row">
        <div class="col-8 offset-2">
          <form @submit.prevent="addConstruction" enctype='multipart/form-data'>
            <p>
              <input class="me-3" type="text" placeholder="Tiêu đề công trình" v-model="title" />
              <input type="text"  placeholder="Năm làm" maxlength="4" v-model="year" />

            </p>
            <p>
              <input class="me-3" type="text" placeholder="Ngày" v-model="date" maxlength="2"/>
              <input type="text" placeholder="Tháng" v-model="month" maxlength="2" />
            </p>
              <p>
              <textarea type="text" placeholder="Nội dung" name="text-content" v-model="content" />
            </p>
            <div class="file">
              <label for="fileImg" style="cursor: pointer">
                Thêm một hay nhiều ảnh
                <input type="file" name="" accept="image/*" id="fileImg" ref="files" multiple/>
              </label>
            </div>
            <p class="mt-5"><input  type="submit" value="Thêm" /></p>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      title: "",
      date: "",
      month: "",
      year: "",
      content : '',
    };
  },
  methods: {
    addConstruction() {
      let formData = new FormData();

      for(let i = 0; i < this.$refs.files.files.length; i++) {
        formData.append('imgs['+i+']', this.$refs.files.files[i])
      }
      let title = this.title.trim().charAt(0).toUpperCase() + this.title.trim().slice(1);
      formData.append("imgs", this.imgs);
      formData.append("title", title);
      formData.append("date", this.date.trim());
      formData.append("month", this.month.trim());
      formData.append("year", this.year.trim());
      formData.append("content", this.content.trim());
      this.$store.dispatch('addConstruction', formData)
      this.title = '',
      this.date = '',
      this.month = '',
      this.year = '',
      this.content = ''
    },
  },
 
};
</script>

<style lang="scss" scoped>

p {
  font-family: "Open Sans", sans-serif;
  font-weight: 400;
  font-size: 1rem;
  letter-spacing: 0.1px;
  line-height: 1.8;
  color: #051922;
  margin: 0 0 1.25rem 0;
}
form p input, textarea {
  width: 49%;
  padding: 15px;
  border: 1px solid #ddd;
  border-radius: 3px;
}
textarea {
    width: 100%;
}
input[type="submit"] {
  background-color: #f28123;
  color: #051922;
  font-weight: 700;
  text-transform: uppercase;
  font-size: 15px;
  border: none !important;
  cursor: pointer;
  padding: 15px 25px;
  transition: 0.3s;
  border-radius: 30px;
  &:hover {
    background-color: #051922;
    color: #f28123;
  }
}
</style>
