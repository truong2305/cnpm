<template>
  <div>
    <div class="container">
      <div class="row">
        <div class="col-3 p-2" v-for="item in products" :key="item.key">
          <div class="product ">
            <div class="product-action">
              <div @click="removeProduct(item.id)"><b-icon icon="trash" aria-hidden="true"></b-icon></div>
            </div>
            <div class="product-content p-2 d-flex justify-content-center align-items-center">
              <div class="text-center mt-5">
                <p>
                {{ item.name }}
              </p>
              <p>
                {{ formatPrice(item.price) }} / {{ item.unit }}
              </p>
              <p>
               {{ item.product_code }}
              </p>
              </div>
            </div>
            <div class="product-img">
              <img :src="`${Base_url}/products/${
                imgSlide(item.imgs)[0]
              }`" alt="">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {Base_url} from '../../main'

export default {
  data() {
    return {
      Base_url
    }
  },
  methods : {
     imgSlide(imgs) {
      return JSON.parse(imgs);
    },
    formatPrice(price) {
     return price.toLocaleString('vi', {style : 'currency', currency : 'VND'});
    },
  
    removeProduct(id) {
      if(confirm('xóa vĩnh viễn sản phẩm này ?')) {
          this.$store.dispatch('removeProduct', id)
      } else return
    }
  },
  computed: {
    products() {
      return this.$store.state.products
    }
  }
}
</script>

<style lang="scss" scoped>
.product {
  border-radius: 5px;
  position: relative;
  overflow: hidden;
  &-action {
    position: absolute;
    top: 1rem;
    right: 1rem;
    z-index: 100;
    div {
      width: 25px;
      height: 25px;
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      background: white;
      cursor: pointer;
    }
  }
  &-content {
    position: absolute;
    width: 100%;
    height: 100%;
    background: rgba(black, 0.6);
    color: white;
    font-weight: 500;
    p {
      font-size: 1.2rem;
    }
  }
  &-img {
    height: 350px;
    overflow: hidden;
    img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  }
}
</style>