<!-- @format -->

<template>
  <div>
    <div class="container mb-5">
      <div class="row">
        <div class="col-8 offset-2">
          <form @submit.prevent="addProduct" enctype='multipart/form-data'>
            <p>
              <input class="me-3" type="text" placeholder="Tên sản phẩm" v-model="name" />
              <input type="text" placeholder="Đường dẫn" v-model="slug" />
            </p>
            <p>
              <input class="me-3" type="number" placeholder="Giá" v-model="price" />
              <input type="text" placeholder="Đơn vị" v-model="unit" />
            </p>

            <p style="position: relative;">
              <input class="me-3" type="text" @change="newCate" @click="show = true" placeholder="Danh mục" v-model="cate_name" />
              <ul class="sub-menu" v-if="show">
                      <li v-for="item in categories" @click="getCategory"  :key="item.id">{{ item.name }}</li>
                    
                    </ul>
              <input type="text" placeholder="Mã sản phẩm" v-model="product_code" />
            </p>
            <p v-if="isNew">
              <input type="text" placeholder="Đường dẫn danh mục" v-model="cate_slug">
            </p>
            <p>
              <textarea type="text" placeholder="Nội dung" name="text-content" v-model="content" />
            </p>
            <div class="file">
              <label for="fileImg" style="cursor: pointer">
                Thêm ảnh chính
                <input type="file" accept="image/*" @change="addImg"  id="fileImg" />
              </label>
              <img :src="src" alt="" />
            </div>
             <div class="file">
              <label for="fileImg" style="cursor: pointer">
                Chọn nhiều mẫu khác <small>( tối đa 7 ảnh )</small>
                <input type="file" accept="image/*"  ref="files" multiple/>
              </label>
            </div>
            <p class="mt-5"><input  type="submit" value="Thêm" /></p>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      name: "",
      price: "",
      unit: "",
      cate_name: "",
      slug: "",
      src: "",
      product_code : '',
      show : false,
      content : '',
      cate_slug : '',
      isNew : false
    };
  },
  methods: {
    getCategory(e) {
      this.cate_name = e.target.textContent;
      this.show = false
    },
    addImg() {
      let fileData = document.getElementById("fileImg").files;
      if (fileData.length > 0) {
        let fileReader = new FileReader();
        fileReader.onload = (fileLoaderEvent) => {
          this.src = fileLoaderEvent.target.result;
        };
        fileReader.readAsDataURL(fileData[0]);
      }
    },
    newCate() {
      this.show = false
    let a =   this.categories.find(item => item.name == this.cate_name)
    if(a) {
      this.isNew = false
    } else {
      this.isNew = true
    }
    },
    addProduct() {
      let fileData = document.getElementById("fileImg").files[0];
      let formData = new FormData();
      
      for(let i = 0; i < this.$refs.files.files.length; i++) {
        formData.append('imgs['+i+']', this.$refs.files.files[i])
      }
      let name = this.name.trim().charAt(0).toUpperCase() + this.name.trim().slice(1);
      formData.append('img', fileData);
      formData.append("name", name);
      formData.append("cate_slug", this.cate_slug.trim());
      formData.append("content", this.content);
      formData.append("price", this.price.trim());
      formData.append("cate_name", this.cate_name.trim());
      formData.append("unit", this.unit.trim());
      formData.append("slug", this.slug.trim());
      formData.append("product_code", this.product_code.trim());
      this.$store.dispatch('addProduct', formData)
      this.name = '',
      this.price = '',
      this.product_code = '',
      this.src = '',
      this.slug = '',
      this.unit = '',
      this.cate_name = '',
      this.content = ''
    },
  },
  computed: {
    categories() {
      return this.$store.state.categories;
    },
  },
};
</script>

<style lang="scss" scoped>
 .sub-menu {
            position: absolute;
            list-style: none;
            background-color: #fff;
            padding: 15px 15px;
            margin: 0;
            left: 0;
            top: 50px;
            border-radius: 3px;
            transition: 0.3s ease;
            box-shadow: 0 0 20px #555555;
            transform: translateY(10px);
            li {
                color: #051922;
                padding: 8px;
                font-weight: 500;
                transition: 0.3s;
                &:hover {
                  color: #f28123;
                }
            }
          }
p {
  font-family: "Open Sans", sans-serif;
  font-weight: 400;
  font-size: 1rem;
  letter-spacing: 0.1px;
  line-height: 1.8;
  color: #051922;
  margin: 0 0 1.25rem 0;
}
form p input, textarea {
  width: 49%;
  padding: 15px;
  border: 1px solid #ddd;
  border-radius: 3px;
}
textarea {
    width: 100%;
}
input[type="submit"] {
  background-color: #f28123;
  color: #051922;
  font-weight: 700;
  text-transform: uppercase;
  font-size: 15px;
  border: none !important;
  cursor: pointer;
  padding: 15px 25px;
  transition: 0.3s;
  border-radius: 30px;
  &:hover {
    background-color: #051922;
    color: #f28123;
  }
}
</style>
