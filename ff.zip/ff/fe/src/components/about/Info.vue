<!-- @format -->

<template>
  <div class="info">
     <p>
      Quý công ty hoặc doanh nghiệp đăng ký Đại Lý Giấy Dán Tường vui lòng liên hệ:
      <span style="width : auto"> {{ name }} </span>
    </p>
    <p><span>Địa chỉ : </span>{{ addr }}</p>
    <p><span>Email : </span><a :href="'mailto:'+email">{{ email }}</a></p>
    <p><span>Di động : </span><a :href="'tel:'+phone">{{ phone }}</a> - <a :href="'tel:'+phone2">{{ phone2 }}</a></p>
    <p><span>Facebook : </span><a :href="fb" target="_blank" rel="noopener noreferrer">{{ fb }}</a></p>
    <p><span>Zalo : </span><a :href="'https://Zalo.me/'+zalo" target="_blank" rel="noopener noreferrer">{{ zalo }}</a></p>

      <br />

    <p>
      Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Pellentesque in ipsum id orci porta dapibus.
      Proin eget tortor risus. Vivamus suscipit tortor eget felis porttitor volutpat. Vestibulum ac diam sit amet quam
      vehicula elementum sed sit amet dui. Donec rutrum congue leo eget malesuada. Vivamus suscipit tortor eget felis
      porttitor volutpat. Curabitur arcu erat, accumsan id imperdiet et, porttitor at sem. Praesent sapien massa,
      convallis a pellentesque nec, egestas non nisi. Vestibulum ac diam sit amet quam vehicula elementum sed sit amet
      dui.
    </p>
      <br />
      <p>
        Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Donec velit neque, auctor
      sit amet aliquam vel, ullamcorper sit amet ligula. Proin eget tortor risus. Praesent sapien massa, convallis a
      pellentesque nec, egestas non nisi. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris blandit
      aliquet elit, eget tincidunt nibh pulvinar a. Cras ultricies ligula sed magna dictum porta. Cras ultricies ligula
      sed magna dictum porta. Sed porttitor lectus nibh. Mauris blandit aliquet elit, eget tincidunt nibh pulvinar a.
      Vestibulum ac diam sit amet quam vehicula elementum sed sit amet dui. Sed porttitor lectus nibh. Vestibulum ac
      diam sit amet quam vehicula elementum sed sit amet dui. Proin eget tortor risus.
      </p>

   
  </div>
</template>

<script>
export default {
  props : ['email','addr', 'phone', 'phone2', 'fb', 'zalo', 'name']
};
</script>

<style lang="scss" scoped>
.info {
  p {
    font-size: 1.2rem;
    text-align: justify;
    span {
      font-weight: 600;
      width: 150px;
      display: inline-flex ;
    }
    a {
      color: inherit;
      text-decoration: none;
    }
  }
   @media (max-width:767.9px) {
    p {
      font-size: 1.1rem;
      span {
        display: inline;
      }
    }
  }
  @media (max-width:576.9px) {
    p {
      font-size: 0.9rem;
    }
  }
}
</style>
